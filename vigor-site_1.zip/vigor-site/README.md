# Vigor — Sitio web (belleza)

Sitio estático de una sola página (`index.html`) para VIGOR, tienda de belleza en Mutatá, Antioquia.

## Publicar en Vercel (sin GitHub)

1. Crea una cuenta gratis en https://vercel.com (puedes usar tu correo o Google).
2. Instala Vercel CLI: `npm install -g vercel`
3. Desde esta carpeta, ejecuta: `vercel`
4. Sigue las instrucciones en pantalla (acepta las opciones por defecto).
5. Al terminar, Vercel te da una URL pública tipo `https://vigor-xxxx.vercel.app`.

## Publicar con GitHub + Vercel (recomendado, permite actualizar fácil)

1. Crea un repositorio nuevo en https://github.com/new (por ejemplo `vigor-web`).
2. Sube este archivo `index.html` al repositorio (botón "Add file" → "Upload files" en GitHub, o con git).
3. Ve a https://vercel.com/new, conecta tu cuenta de GitHub y elige el repositorio.
4. Deja la configuración por defecto (es un sitio estático) y haz clic en "Deploy".
5. Cada vez que subas cambios al repositorio, Vercel actualiza el sitio automáticamente.

## Publicar con git desde la terminal

```bash
git init
git add index.html README.md
git commit -m "Sitio Vigor - tienda de belleza"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/vigor-web.git
git push -u origin main
```

Luego conecta el repo en https://vercel.com/new como se explica arriba.
